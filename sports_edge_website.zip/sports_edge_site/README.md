# Sports Edge — Projection Lab

A mobile-friendly static website prototype for NFL, MLB, NBA, and NHL player props and game lines.

## Run locally
Open `index.html` in a browser. No build step is required.

## Deploy free with GitHub Pages
1. Create/sign in to GitHub and create a new public repository, e.g. `sports-edge`.
2. Upload `index.html` and this `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for the Pages deployment. GitHub will show the published URL under Settings → Pages.

Alternative: create a new static site on Netlify and drag in the folder (or connect the GitHub repository).

## Important limitations
This is a functional front-end prototype, not a live betting-data product. It uses manually entered averages and example rows. It does not fetch real-time odds, injury news, schedules, box scores, or prop markets, and it does not produce calibrated win probabilities.

For a live-data version, choose a data provider whose license permits your use. Keep paid API keys on a server or serverless function, never in browser JavaScript. Use historical snapshots and backtest projections by league/market; report sample size, error, calibration, and performance against closing lines. Free public data often lacks licensed sportsbook prop lines and may change without notice.
